function onSubmit() {
    options.userName = $("#username").val();
    options.password = $("#password").val();
    var ip = localStorage["ip"];
    if(ip == "" || ip == null)
    ip ="savetron.2440066.xyz";
    if($("#ip").length != 0) {
       ip = $("#ip").val();
       localStorage["ip"] = ip;
    }
    var port = localStorage["port"];
    if(port == "" || port == null)
      port =8083;
    if($("#port").length != 0) {
       port = $("#port").val();
       localStorage["port"] = port;
    }
    client = new Paho.MQTT.Client(ip,parseInt(port),clientid);
    client.onConnectionLost = onConnectionLost;
    client.onMessageArrived = onMessageArrived;
    client.connect(options);
}
var clientid = "testl2l"+new Date().getTime();
var client;


var options = {
  useSSL: true,
  userName: "",
  password: "",
  onSuccess:onConnect,
  onFailure:doFail
}

// connect the client
$( document ).ready(function() {
    if(location.href.indexOf("admin") >0 ) return;
    if(localStorage["userName"] != "")
        $("#username").val(localStorage["userName"]);
    if(localStorage["password"] != "" && localStorage["userName"] != "") {
        $("#username").val(localStorage["userName"]);
        $("#password").val(localStorage["password"]);
       // onSubmit();
    }
});


// called when the client connects
function onConnect() {
  // Once a connection has been made, make a subscription and send a message.
  console.log("connect");
  localStorage["userName"] = $("#username").val();
  localStorage["password"] = $("#password").val();
  $(".login").hide();
  $(".loginError").hide();
  $(".buttonsLight").show();
  $(".logout").show();
  client.subscribe("/LL-"+localStorage["userName"]+"/#");
  var message = new Paho.MQTT.Message("HELLO");
  message.destinationName = "/LL-"+localStorage["userName"];
  client.send(message);
}

function onConnectionLost(responseObject) {
    if (responseObject.errorCode !== 0) {
      console.log("onConnectionLost:"+responseObject.errorMessage);
      debugger;
      client.connect(options);
    }

  }
function doFail(e){
  console.log(e);
  $(".loginError").show();
$(".loginError").show;
}

function onMessageArrived(message) {
    
    var buttonEle = "<li id='replaceListId'><div style='float:left'>replaceRoomName</div>"+
    "<label class='switch pull-right' id='labelId' style='display:none'>"+
    "<input type='checkbox' roomDetails='roomDetailsAttr' id='buttonId'   checked deviceId ='deviceIDReplace' onclick='onSend(this)'>"+
    "<span class='slider round'></span>"+
    "</label></li>";
    var roomUl = "<ul roomDetails='roomDetailsAttr' class ='roomUl' id='replaceUlId'></ul>"
    var roomPill = "<li id='roomDetailsAttr' data-toggle='pill' onclick='showRoomDevices(this)'><a href='#'>replaceRoomName</a></li>"
    var text;
    if(message.payloadString == "null") return;
    if(message.payloadString.indexOf("status\":") == -1)return;
    var status = JSON.parse(message.payloadString).status;
    if(status == "1")
      text = true;
    else {
      text = false;
    }
    var eachTopic = message.destinationName.split("/");
    var roomDetails = eachTopic[2].split("-");
    var roomName = roomDetails[1];
    var roomDetailsAttr = eachTopic[2];
    var listId = roomName+eachTopic[3]+"li";
    var buttonId = roomName+eachTopic[3];
    var deviceId = eachTopic[3]; //DeviceID to be marked here
    var replaceRoomName = roomName + " "+ deviceId;
    buttonEle = buttonEle.replace("replaceListId", listId);
    buttonEle = buttonEle.replace("replaceRoomName",replaceRoomName);
    buttonEle = buttonEle.replace("buttonId",buttonId);
    buttonEle = buttonEle.replace("deviceIDReplace",deviceId);
    buttonEle = buttonEle.replace("roomDetailsAttr",roomDetailsAttr);
    buttonEle = buttonEle.replace("labelId",buttonId+"label");
    roomUl = roomUl.replace("replaceUlId",roomName);
    roomUl = roomUl.replace("roomDetailsAttr",roomDetailsAttr);
    roomPill = roomPill.replace("replaceRoomName",roomName);
    roomPill = roomPill.replace("roomDetailsAttr",roomDetailsAttr);

    if($("#"+roomName).length == 0) {
        $("#listOfDevices").append(roomUl);
        $(".roomPills").append(roomPill)
    }
    if($("#"+listId).length == 0) {
        $("#"+roomName).append(buttonEle);
    }
    $("#"+buttonId).prop('checked', text);
    $("#"+buttonId+"label").show();
    /*if(message.destinationName.indexOf("light0") > -1) {
      $("#light0").text(text);
      $("#light0").show();
      $("#light0li").append(message.destinationName)
    }

    if(message.destinationName.indexOf("light1") > -1) {
      $("#light1").text(text);
      $("#light1").show();
      $("#light1li").append(message.destinationName)
    }
    if(message.destinationName.indexOf("light2") > -1) {
      $("#light2").text(text);
      $("#light2").show();
      $("#light2li").append(message.destinationName)
    }
    if(message.destinationName.indexOf("light3") > -1) {
      $("#light3").text(text);
      $("#light3").show();
      $("#light3li").append(message.destinationName)
    }*/
  }
  function onSend(ele) {
    var text = $(ele).prop("checked");
    if(text == true) text = "1";
    else text = "0";
      var message = new Paho.MQTT.Message(text);
    message.destinationName = "/LL-"+localStorage["userName"]+"/"+$(ele).attr("roomDetails")+"/"+$(ele).attr("deviceid")+"/control";
    client.send(message);
  }

  function showRoomDevices(ele) {
      $.each($(".roomUl") , function(index,element){
          if($(ele).attr("id") == "all" || $(ele).attr("id") == $(element).attr("roomDetails")){
            $(element).show();
          } else {
              $(element).hide();
          }
      }) 
  }
  
  function logOut() {
      localStorage["userName"] = "";
      localStorage["password"] = "";
      window.location.reload();

  }